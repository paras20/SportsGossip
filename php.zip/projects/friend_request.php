<?php include("headerinc.php") ?>
<?php
$friendrequests="select * from friend_requests where user_to='$user'";
if($result=$con->query($friendrequests))
{
	if($result->num_rows==0)
	{
		echo"no requests";
	}
	else{
		
		while($row=@$result->fetch_array())
		{
			$id=$row[0];
			$user_from=$row[1];
			$user_to=$row[2];
			echo $user_from."wants to be your friend<br>";
			
			

         if(isset($_POST['acceptrequest'.$user_from]))
	
        {
	      $friendarray_count_friend="";
	      $friend_array_friend="";
	      $get_friend_check="select * from users where username='$user'";
	      if($result=$con->query($get_friend_check))
	      {
		
		
			while($row=$result->fetch_array())
			{
				$friend_array=$row[10];
				$friendarray_explode=explode(",",$friend_array);
				$friendarray_count=count($friendarray_explode);
			
			}
		
	
	      }
	
	      else{
		
		echo "query error";
	          }
	
	$get_friend_check_friend="select * from users were username='$user_from'";
	if($result=$con->query($get_friend_check_friend))
	{
		
	
			while($row=$result->fetch_array())
			{
				$friend_array_friend=$row[10];
				$friendarray_explode_friend=explode(",",$friend_array_friend);
				$friendarray_count_friend=count($friendarray_explode_friend);
			}
		
	}
	
	if($friend_array=="")
	{
		
		$friendarray_count=count(null);
		
	}
	if($friend_array_friend=="")
	{
		
		$friendarray_count_friend=count(null);
	}
	if($friendarray_count==null)
	{
		$add_friend_query="update users set friend_array=concat(friend_array,'$user_from') where username='$user'";
		if($con->query($add_friend_query))
		{
			echo"added in ur friend array first case";
		}
		else{
			echo"error";
		}
	}
	
	if($friendarray_count_friend==null)
	{
		$add_friend_query_friend="update users set friend_array=concat(friend_array,'$user_to') where username='$user_from'";
	    if($con->query($add_friend_query_friend))
		{
		echo"added in his friends first case";
		}
		else{
			echo"error";
		}
	}
	if($friendarray_count>=1)
	{
		$add_friend_query="update users set friend_array=concat(friend_array,',$user_from') where username='$user'";
		if($con->query($add_friend_query))
		{
			echo"added in ur friends";
		}
		else{
			echo"error";
		}
	}
	if($friendarray_count_friend>=1)
	{
		$add_friend_query_friend="update users set friend_array=concat(friend_array,',$user_to') where username='$user_from'";
	    if($con->query($add_friend_query_friend))
		{
		 echo"added in his friends";
		}
		else{
			echo"error";
		}
	}
	
	

    }

    ?>
            <form action="friend_request.php" method="post">
            <input type="submit" name="acceptrequest<?php echo$user_from;?>" value="accept">
             <input type="submit" name="ignorerequest<?php echo$user_from;?>" value="ignore">
            </form> 
			
     <?php
           }
		}

		
	
}

else{
	
	echo "there is query error";
}
?>
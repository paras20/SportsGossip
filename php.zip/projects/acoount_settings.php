<?php
include("headerinc.php");
if ($username) {

}
else
{
 die ("You must be logged in to view this page!");
?>
<h2>edit below</h2>
-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2016 at 02:23 PM
-- Server version: 5.7.9
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sports`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `body` text NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `type`, `date`, `body`, `status`) VALUES
(1, 'football', '2016-07-22', 'La liga football world cup kicks off!', 0);

-- --------------------------------------------------------

--
-- Table structure for table `friend_requests`
--

DROP TABLE IF EXISTS `friend_requests`;
CREATE TABLE IF NOT EXISTS `friend_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_from` varchar(255) NOT NULL,
  `user_to` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
CREATE TABLE IF NOT EXISTS `history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `body` text NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `body`, `date`) VALUES
(1, '<b>2015</b> Floyd Mayweather Jr. is stripped of his WBO welterweight boxing title after failing to pay his $200,000 & vacate his light middleweight title', '2016-07-06'),
(2, '<b>1941</b> NY Yankees unveil a monument to Lou Gehrig in centerfield', '2016-07-07'),
(3, '<b>1981</b>Birth of the first international cricketer MS DHONI from Jharkhand', '2016-07-07'),
(4, '<b>1972</b>Sourav Ganguly, who was born today, was first an elegant strokeplayer who struggled on the periphery.', '2016-07-08'),
(5, '<b>1932</b>\r\nThe hundredth first-class hundred for Herbert Sutcliffe. And it came in a big Yorkshire win against Gloucestershire in Bradford. He scored 83 in the first innings and 132 in the second.', '2016-07-08'),
(6, '<b>1957</b>\r\nBeing a West Indian spinner in the 1980s was a bit like being a trained opera singer in a boy band, so spare a thought for Clyde Butts, who was born today in a village called Perseverance. ', '2016-07-08'),
(7, '<b>1965</b>\r\nA record-breaking innings from John Edrich. Nobody has scored more runs in boundaries in a Test innings than Edrich did in this meaty 310 not out against New Zealand at Headingley. ', '2016-07-09'),
(8, '<b>1983</b>\r\nBirth of Shaun Marsh, who scored a century on Test debut in Sri Lanka - only one of five Australians to achieve the landmark in an away game - in 2011, three years after breaking into the one-day side. ', '2016-07-09');

-- --------------------------------------------------------

--
-- Table structure for table `polls`
--

DROP TABLE IF EXISTS `polls`;
CREATE TABLE IF NOT EXISTS `polls` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ques` text NOT NULL,
  `yes` int(10) NOT NULL,
  `no` int(10) NOT NULL,
  `user_array` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `polls`
--

INSERT INTO `polls` (`id`, `ques`, `yes`, `no`, `user_array`) VALUES
(1, 'india will win 2017 world cup.?', 1, 1, 'ab,remo2016'),
(2, 'Virat kohli will break the records of sachin tendulkar.', 0, 1, 'ab');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` text NOT NULL,
  `date_added` date NOT NULL,
  `added_by` varchar(255) NOT NULL,
  `user_posted_to` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `body`, `date_added`, `added_by`, `user_posted_to`) VALUES
(19, 'another post about something', '2016-06-28', 'ab', 'golf'),
(23, 'argentina out of copa america league', '2016-06-28', 'ab', 'football'),
(33, 'last post', '2016-06-29', 'ab', 'golf'),
(37, 'about baseball\r\n', '2016-06-29', 'ab', 'baseball'),
(42, 'posted about cricket ', '2016-06-29', 'ab', 'cricket'),
(43, 'vgukvhukgyuov by abc', '2016-06-29', 'sharmabc', 'football'),
(45, 'ctfudcrtfufctyj', '2016-06-29', 'sharmabc', 'golf'),
(46, 'cfrtucftudytrufvyulbhgv', '2016-06-29', 'sharmabc', 'basketball'),
(47, 'cetdftgubgvfxzeserfhn', '2016-06-29', 'sharmabc', 'cricket'),
(51, 'good night', '2016-06-30', 'ab', 'football'),
(54, 'yo posting abt basket\r\n', '2016-07-04', 'yo', 'basketball');

-- --------------------------------------------------------

--
-- Table structure for table `post_comments`
--

DROP TABLE IF EXISTS `post_comments`;
CREATE TABLE IF NOT EXISTS `post_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_body` tinytext NOT NULL,
  `posted_by` varchar(255) NOT NULL,
  `posted_to` varchar(255) NOT NULL,
  `posted_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post_comments`
--

INSERT INTO `post_comments` (`id`, `post_body`, `posted_by`, `posted_to`, `posted_id`) VALUES
(1, 'first comment', 'ab', 'ab', 51),
(2, 'second comment', 'yo', 'ab', 51),
(3, 'commentttt', 'yo', 'ab', 51),
(6, 'abc', 'ab', 'ab', 42),
(7, 'kya h', 'ab', '51', 51),
(8, 'dhoni', 'ab', '42', 42),
(9, 'replying', 'ab', '54', 54),
(10, 'ok', 'ab', '54', 54),
(11, 'h', 'ab', '54', 54),
(12, 'hii', 'ab', '47', 47),
(13, 'ihih', 'ab', '47', 47),
(14, 'ghghghg', 'ab', '47', 47),
(15, 'uhnin', 'ab', '54', 54),
(16, 'paras', 'ab', '54', 54),
(17, 'hihihihihih', 'ab', '54', 54),
(18, 'vheicvwe', 'ab', '54', 54);

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

DROP TABLE IF EXISTS `results`;
CREATE TABLE IF NOT EXISTS `results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` text NOT NULL,
  `date_added` date NOT NULL,
  `type` varchar(255) NOT NULL,
  `verdict` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id`, `body`, `date_added`, `type`, `verdict`) VALUES
(1, 'spain beats argentina 1-0', '2016-06-30', 'football', 'win'),
(2, 'france reaches semi finals', '2016-06-30', 'football', 'news');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `sign_up_date` date NOT NULL,
  `activated` enum('0','1') NOT NULL,
  `bio` text NOT NULL,
  `profile_pic` text NOT NULL,
  `friend_array` text NOT NULL,
  `security_question` text NOT NULL,
  `security_answer` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `first_name`, `last_name`, `email`, `password`, `sign_up_date`, `activated`, `bio`, `profile_pic`, `friend_array`, `security_question`, `security_answer`) VALUES
(1, 'sharmabc', 'Craig', 'Bolt', 'sharma@gmail.com', '123456', '2016-06-28', '0', 'For some people motorsport is a kind of madness, but for me it is passion', 'd.jpg', 'yo,ab,remo2016', 'what is my pet''s name', 'cherry'),
(2, 'ab', 'Dory', 'Singh', 'a@gmail.com', '1', '2016-06-28', '0', '" I enjoy meeting new people and finding ways to help them have an uplifting experience.Sport has always been a massive part of my life ever since I started playing football at the age of seven."', 'rob-weisback.jpg', 'yo,sharmabc,remo2016', '', ''),
(3, 'yo', 'larry', 'page', 'yo@gmail.com', '1', '2016-06-30', '0', '"I am dedicated, outgoing, and a team player.At age ten I had been to 12 different countries, across 3 continents, getting a taste of a multiculturalism that would taint my life to the present day."', 'larry.jpg', 'sharmabc,ab,remo2016', '', ''),
(4, 'remo2016', 'Remo', 'Dsouza', 'remo@gmail.com', '123456', '2016-07-02', '0', 'â€œPeople find me to be an upbeat, self-motivated team player with excellent communication skills.Today within our society, the wide sport sector is expanding and developing and is becoming more influential in our lives. This increase in popularity and accessibility has had an affect on my interest and involvement in this subject and the different aspects involved in sport..."', 're.jpg', 'sharmabc,ab,yo', '', ''),
(5, 'iamkary', 'kary', 'smith', 'kary@gmail.com', '123456', '2016-07-08', '0', '', '', '', '', ''),
(6, 'jb', 'justin', 'bieber', 'jb@gmail.com', '1234567', '2016-07-08', '0', '', '', '', 'wht is my lucky color', 'red');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

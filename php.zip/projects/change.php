		<?php include("headerinc.php");?>
		<?php
		
		$userchange=$_SESSION['changeuser'];
		$ans=$_SESSION['answer'];
		if(isset($_POST['submit']))
{   
	$youranswer=$_POST['youranswer'];
	if($youranswer==$ans)
	{   
		echo'<form class="fbutton" action="#" method="post">
<p>NEW PASSWORD:</p>

New Password &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="password" name="newpassword" id="newpassword" size="30"/><br>
Confirm Password&nbsp;<input type="password" name="newpassword2" id="newpassword" size="30"/><br><br>
<input type="submit" name="senddata" id="senddata" value="Change Password"/>
</form>';
	}
	else{
		echo"incorrect answer";
	}
}
	if(isset($_POST['senddata']))
	{
		
         

			if($con==true)
			{
				$cmd="select * from users where username='$userchange'";
				if($r=$con->query($cmd))
				{
	                while($rows=$r->fetch_array())
					{
			$new_password=$_POST["newpassword"];
			$repeat_password=$_POST["newpassword2"];
					}
	
					if($new_password==$repeat_password)
					{
	                 
					  
					 $cmdpass="update users set password='$new_password' where username='$userchange'";
					if($con->query($cmdpass)==true)
					{	
					echo"succesfully updated";
					}
					else{
						echo"error query";
					}
					
					}
					else
					{
					echo"password doesnt match";
					}
			    }
				else{
					echo"query error";
				}
			}
			else{
				echo"connection error";
			}
	
       }
		
		
		

?>
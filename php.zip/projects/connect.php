<?php
$con=new mysqli("localhost","root","","sports");
if($con==true)
{
	
}	
else
{
	echo"database connection error";
}
?>
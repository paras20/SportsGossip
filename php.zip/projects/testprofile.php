<?php include("headerinc.php"); 


?>
<?php
    
	$username=$_SESSION['user_login'];
 	
	$check = "SELECT * FROM users WHERE username='$username'";
	if (($result=$con->query($check))) 
	{   if($result->num_rows>0)
		{
		while($rows=$result->fetch_array())
		{
	$username=$rows[1];
	
     
	}
	}
	
	else{
		echo "no user exists";
		exit();
	}
	
	}

	
?>

<div>
<form method="post" action="search.php">
<input type="text" name="searchbox" />
<input type="submit" name="search" value="find"/>
</form>

</div>
<div>

<img id="profileimage"src="" height="250" width="200" alt="<?php echo $username;?> Profile"title="<?php echo $username;?>'s Profile"/>
</div>


<div class="categories">


<a href="profile.php?cat=football"><img id="football" src="football.png" /></a>
<a href="profile.php?cat=golf"><img id="golf" src="golf.png" /></a>
<a href="profile.php?cat=basketball"><img id="basketball"src="basketball.png" /></a>
<a href="profile.php?cat=baseball"><img id="baseball"src="baseball.png" /></a>
<a href="profile.php?cat=cricket"><img id="baseball"src="cricket.png" /></a>
</div>
<br><br>
<div class="postform" >
<form  method="POST">
<textarea id="post" name="post" rows="3" cols="39"></textarea>

<input id="postbutton" type="submit"  name="send" value="Post"  />
</form>

<br>
<br>

</div>


<?php
$category=$_GET['cat'];

$allposts="";

if($category==1)
{
	$showpost="select * from posts where added_by='$username' order by id DESC";
	
if($result=$con->query($showpost))
	{
		if($result->num_rows>0)
		{ while($row=$result->fetch_array())
			{
				$allpost=$row[1];
				$dateadded=$row[2];
				$postedby=$row[3];
			echo '<div class="profileposts">';
			echo '<u>'.$postedby.'</u><br>';
			echo $allpost.'<div id="mark" > Posted on <br>'.$dateadded.'</div>';
			echo'</div>';
			}
		}
	}
}
	

else{
$showpost="select * from posts where user_posted_to='$category'";
	
if($result=$con->query($showpost))
	{
		if($result->num_rows>0)
		{ while($row=$result->fetch_array())
			{
				$allpost=$row[1];
				$dateadded=$row[2];
				$postedby=$row[3];
			echo '<div class="profileposts">';
			echo '<u>'.$postedby.'</u><br>';
			echo $allpost.'<div id="mark" ><br>'.$dateadded.'</div>';
			echo'</div>';
			}
		}
	}
}
?>
<?php
if(isset($_POST['send']))
{   $body=$_POST['post'];
    $d=date("Y-m-d");
	$postit="insert into posts values('0','$body','$d','$user','$category')";
	if($con->query($postit))
	{
		header("location:#");
	}
	else{
		echo"query error";
	}
	
}


?>
<?php 
$errormsg="";
if(isset($_POST["addfriend"]))
{
	$friend_request=$_POST["addfriend"];
	$user_to=$user;
	$user_from=$username;
	if($user_to==$username)
		$errormsg="u cant send friend request to youself ";
	else{
		$create_request="insert into friend_requests values('0','$user_to','$user_from')";
		if($result=$con->query($create_request))
			echo"request has been sent";
	}
	
}
else{
	
}
?>

<?php 
if($user)
{
echo'<form  method="post">';
echo $errormsg;
echo'<br>';
echo'<input type=submit value="Add as Friend" name="addfriend"/>
</form>';
}
?>

<div class="textheader"><?php echo $username;?>'s profile</div>
<div class="profileleftsidecontent">
<?php
$about_query="select * from users where username='$username'";
if($result=$con->query($about_query))
	{
		if($result->num_rows>0)
		{ while($row=$result->fetch_array())
			{
				$about=$row[8];
				echo $about;
			}
		}
	}
?>
</div>

<div class="textheader"><?php echo $username;?>'s followers</div>
<div class="profileleftsidecontent">
<br>
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
<img src="#" height="50" width="40"/>&nbsp;&nbsp;
</div>

</div>
</body>
</html>
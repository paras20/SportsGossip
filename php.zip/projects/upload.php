<html>
<body>
<form action="upload.php" method="post" enctype="multipart/form-data">
<input type="file" name="image"/>
<input type="submit" name="b1" value="submit"/>
</form>
<?php
if(isset($_FILES['image']))
{
	
	$errors=array();
	$filename=$_FILES['image']['name'];
	$filesize=$_FILES['image']['size'];
	$file_tmp=$_FILES['image']['tmp_name'];
	$filetype=$_FILES['image']['type'];
	$fileext=explode('.',$filename);
	$ext=strtolower($fileext[1]);
	$exp=array("jpeg","jpg","png");
	if(in_array($ext,$exp)==false)
	{
		$errors[]="not allowed";
		
	}
if($filesize>2097152)
{
	$errors[]="file size error";

	
}
if(empty($errors)==true)
{
	
	if(move_uploaded_file($file_tmp,"img/".$filename))
	echo"success";
else{
	echo "not successful";
	
}
}	
else{
	
	print_r($errors);
	}
	
	
}

?>
</body>
</html>
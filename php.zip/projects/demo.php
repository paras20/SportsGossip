<?php include("headerinc.php");?>
<?php
$cmd="select * from users";
if($result=$con->query($cmd))
{
while($row=$result->fetch_array())
{
$list=$row[10];
$a=explode(',',$list);
$c=count($a);
if($list=="")
{
	$c=0;
}
echo$c;

}

}

?>
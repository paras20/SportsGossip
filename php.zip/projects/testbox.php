<?php
session_start();
if(!isset($_SESSION['user_login']))
{
	$user="";
}
else{
	$user=$_SESSION['user_login'];
	
}
$getid=$_GET['id'];
echo $getid;
$con=new mysqli("localhost","root","","sports");
$postdetails="select * from users where id='$getid'";
echo'<form action="box_frame.php" method="post">';
echo'<textarea name="postcomment" rows=3 cols=30></textarea><br>';
echo'<input type="submit" name="postcommentbutton"/>';
echo'</form>';

?>
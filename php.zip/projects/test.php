<html>
<head>
<style>
img{
	
	
	
	
	border:3px solid black;
    border-radius: 50%;
}
</style>
</head>
<body>

<img src="baseball.png"/>
</body>
</html>
